package com.cg.enumeration;

public enum TransactionStatus {
    SUCCESS,
    FAILED,
    PENDING
}
