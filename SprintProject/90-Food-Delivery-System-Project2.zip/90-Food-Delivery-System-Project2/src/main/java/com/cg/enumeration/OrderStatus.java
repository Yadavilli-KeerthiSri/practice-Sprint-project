package com.cg.enumeration;

public enum OrderStatus {
	PLACED,
    PREPARING,
    PICKED_UP,
    OUT_FOR_DELIVERY,
    DELIVERED,
    CANCELLED
}
