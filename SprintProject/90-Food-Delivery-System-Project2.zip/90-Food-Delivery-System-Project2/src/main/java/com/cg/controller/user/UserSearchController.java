package com.cg.controller.user;

import com.cg.entity.MenuItem;
import com.cg.entity.Restaurant;
import com.cg.service.SearchService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/user")
public class UserSearchController {
 
    @Autowired
    private SearchService searchService;
 
    @GetMapping("/search")
    public String search(
            @RequestParam("keyword") String keyword,
            Model model) {
 
        List<Restaurant> restaurants = searchService.searchRestaurants(keyword);
        List<MenuItem> menuItems = searchService.searchMenuItems(keyword);
 
        model.addAttribute("restaurants", restaurants);
        model.addAttribute("menuItems", menuItems);
        model.addAttribute("keyword", keyword);
 
        return "user/search-results";
    }
}
 

