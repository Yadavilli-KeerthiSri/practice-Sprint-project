package com.cg.entity;

public enum OrderStatus {
	PENDING,
	PLACED,
    CONFIRMED,
    PREPARING,
    PICKED_UP,
    OUT_FOR_DELIVERY,
    DELIVERED,
    CANCELLED,
    REFUNDED
}
