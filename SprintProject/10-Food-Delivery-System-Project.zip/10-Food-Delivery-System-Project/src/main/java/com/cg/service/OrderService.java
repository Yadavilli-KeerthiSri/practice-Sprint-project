package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Order;
import com.cg.entity.OrderStatus;
import com.cg.iservice.IOrderService;
import com.cg.repository.OrderRepository;

@Service
public class OrderService implements IOrderService{
	@Autowired
    private OrderRepository orderRepository;
 
    @Override
    public Order saveOrder(Order order) {
        return orderRepository.save(order);
    }
 
    @Override
    public Order getOrderById(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));
    }
 
    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }
 
    @Override
    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }
 
    @Override
    public void updateOrderStatus(Long orderId, OrderStatus status) {
        Order order = getOrderById(orderId);
        order.setStatus(status);
        orderRepository.save(order);
    }
    
    @Override
    public List<Order> getOrdersByUsername(String username) {
    	return orderRepository.findByCustomer_User_Username(username); 
    }
}
