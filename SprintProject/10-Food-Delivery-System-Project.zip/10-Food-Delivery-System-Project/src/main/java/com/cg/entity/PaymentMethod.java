package com.cg.entity;

public enum PaymentMethod {
	UPI,
    CARD,
    NET_BANKING,
    CASH_ON_DELIVERY
}
