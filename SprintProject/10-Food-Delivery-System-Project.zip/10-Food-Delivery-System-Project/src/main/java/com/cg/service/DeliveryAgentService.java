package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.DeliveryAgent;
import com.cg.iservice.IDeliveryAgentService;
import com.cg.repository.DeliveryAgentRepository;

@Service
public class DeliveryAgentService implements IDeliveryAgentService{
	 @Autowired
	 private DeliveryAgentRepository agentRepository;
	 
	 @Override
	 public DeliveryAgent saveAgent(DeliveryAgent agent) {
	     return agentRepository.save(agent);
	 }
	 
	 @Override
	 public DeliveryAgent getAgentById(Long id) {
	     return agentRepository.findById(id)
	                           .orElseThrow(() -> new RuntimeException("Agent not found"));
	 }
	 
     @Override
	 public List<DeliveryAgent> getAllAgents() {
         return agentRepository.findAll();
	 }
	 
	 @Override
	 public void deleteAgent(Long id) {
	     agentRepository.deleteById(id);
	 }
}
