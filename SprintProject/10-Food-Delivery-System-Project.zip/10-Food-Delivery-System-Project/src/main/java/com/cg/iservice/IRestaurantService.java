package com.cg.iservice;

import java.util.List;

import com.cg.entity.Restaurant;

public interface IRestaurantService {
	Restaurant saveRestaurant(Restaurant restaurant);
    Restaurant getRestaurantById(Long id);
    List<Restaurant> getAllRestaurants();
    void deleteRestaurant(Long id);
}
