package com.cg.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import com.cg.service.CustomUserDetailsService;

import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
	@Autowired
    private CustomUserDetailsService userDetailsService;
	
	@Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
 
    @Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
 
        http
          .csrf(csrf -> csrf.disable())
          .authorizeHttpRequests(auth -> auth
 
            // PUBLIC
            .requestMatchers("/login", "/register").permitAll()
 
            // ADMIN ONLY
            .requestMatchers(
                "/restaurants/add",
                "/restaurants/delete/**",
                "/menu/add",
                "/menu/delete/**",
                "/agents/**",
                "/admin/**"
            ).hasRole("ADMIN")
 
            // USER ONLY
            .requestMatchers("/orders/**", "/orders/track/**", "/payments/**")
            .hasRole("USER")
 
            // COMMON
            .anyRequest().authenticated()
          )
          .formLogin(form -> form
              .loginPage("/login")
              .defaultSuccessUrl("/dashboard", true)
          )
          .logout(logout -> logout
              .logoutUrl("/logout")
              .logoutSuccessUrl("/login")
          );
 
        return http.build();
    }
}
