package com.cg.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.User;
import com.cg.repository.UserRepository;

@Controller
@RequestMapping("/password")
public class PasswordController {
	@Autowired
    private UserRepository userRepository;
 
    @Autowired
    private PasswordEncoder passwordEncoder;
 
    @GetMapping("/change")
    public String changePasswordPage() {
        return "profile/change-password";
    }
 
    @PostMapping("/change")
    public String changePassword(
            @RequestParam String currentPassword,
            @RequestParam String newPassword,
            Principal principal,
            Model model) {
 
        User user = userRepository.findByUsername(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));
 
        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            model.addAttribute("error", "Current password is incorrect");
            return "profile/change-password";
        }
 
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
 
        model.addAttribute("success", "Password updated successfully");
        return "profile/change-password";
    }
}
