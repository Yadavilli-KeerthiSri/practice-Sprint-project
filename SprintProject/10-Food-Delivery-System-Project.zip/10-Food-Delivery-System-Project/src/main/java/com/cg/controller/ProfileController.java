package com.cg.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.User;
import com.cg.repository.UserRepository;

@Controller
@RequestMapping("profile")
public class ProfileController {
	 @Autowired
	    private UserRepository userRepository;
	 
	    @GetMapping
	    public String profile(Model model, Principal principal) {
	 
	        String username = principal.getName();
	        User user = userRepository.findByUsername(username)
	                .orElseThrow(() -> new RuntimeException("User not found"));
	 
	        model.addAttribute("user", user);
	        return "profile/profile";
	    }
	 
	    @PostMapping("/update")
	    public String updateProfile(@ModelAttribute User user) {
	 
	        User existingUser = userRepository.findById(user.getId())
	                .orElseThrow(() -> new RuntimeException("User not found"));
	 
	        existingUser.setUsername(user.getUsername());
	        userRepository.save(existingUser);
	 
	        return "redirect:/profile?success";
	    }
}
