package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Customer;
import com.cg.iservice.ICustomerService;
import com.cg.repository.CustomerRepository;

@Service
public class CustomerService implements ICustomerService {
	@Autowired
    private CustomerRepository customerRepository;
 
    @Override
    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer);
    }
 
    @Override
    public Customer getCustomerById(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
    }
 
    @Override
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }
 
    @Override
    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id);
    }
}