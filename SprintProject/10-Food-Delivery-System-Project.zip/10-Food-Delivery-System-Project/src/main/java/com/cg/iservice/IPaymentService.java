package com.cg.iservice;

import java.util.List;

import com.cg.entity.Payment;

public interface IPaymentService {
	Payment savePayment(Payment payment);
    Payment getPaymentById(Long id);
    List<Payment> getAllPayments();
    void deletePayment(Long id);
}
